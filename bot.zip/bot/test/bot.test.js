import assert from "node:assert/strict";
import { beforeEach, test } from "node:test";
import { createBot } from "../src/bot.js";
import { loadConfig } from "../src/config.js";
import { openDb } from "../src/db.js";

const ADMIN = 100;
const USER = 200;
const config = loadConfig({
  BOT_TOKEN: "1:test",
  ADMIN_IDS: String(ADMIN),
  CHANNEL_ID: "@kanal",
});

let bot, db, calls, memberStatus, nextUpdateId, blockedChats;

const person = (id) => ({ id, is_bot: false, first_name: id === ADMIN ? "Admin" : "Ali <b>" });
const chat = (id) => ({ id, type: "private", first_name: "x" });

const sent = (method, chatId) =>
  calls.filter((c) => c.method === method && (chatId === undefined || c.payload.chat_id === chatId));
const last = (method, chatId) => sent(method, chatId).at(-1)?.payload;
const buttons = (payload) => payload.reply_markup.inline_keyboard.flat();
const hasCallback = (payload, data) => buttons(payload).some((b) => b.callback_data === data);

function message(from, fields) {
  return bot.handleUpdate({
    update_id: nextUpdateId++,
    message: { message_id: nextUpdateId, date: 1, from: person(from), chat: chat(from), ...fields },
  });
}

const say = (from, text) =>
  message(from, {
    text,
    ...(text.startsWith("/") && {
      entities: [{ type: "bot_command", offset: 0, length: text.split(" ")[0].length }],
    }),
  });

const press = (from, data) =>
  bot.handleUpdate({
    update_id: nextUpdateId++,
    callback_query: {
      id: String(nextUpdateId),
      from: person(from),
      chat_instance: "x",
      data,
      message: { message_id: 1, date: 1, chat: chat(from), text: "x" },
    },
  });

function setPaymentSettings() {
  db.setSetting("card_number", "8600123412341234");
  db.setSetting("admin_username", "real_admin");
}

const video = { file_id: "VID1", kind: "video", caption: null };

beforeEach(() => {
  db = openDb(":memory:");
  calls = [];
  memberStatus = "member";
  nextUpdateId = 1;
  blockedChats = new Set();

  bot = createBot({
    config,
    db,
    botInfo: { id: 1, is_bot: true, first_name: "Bot", username: "test_bot" },
  });
  bot.api.config.use(async (_prev, method, payload) => {
    calls.push({ method, payload });
    if (blockedChats.has(payload.chat_id)) {
      return { ok: false, error_code: 403, description: "Forbidden: bot was blocked by the user" };
    }
    const result =
      method === "getChatMember"
        ? { status: memberStatus, user: person(payload.user_id) }
        : method.startsWith("send")
          ? { message_id: 1, date: 1, chat: chat(payload.chat_id) }
          : true;
    return { ok: true, result };
  });
});

test("obuna bo'lmagan foydalanuvchi xush kelibsiz va kanal tugmasini oladi", async () => {
  memberStatus = "left";
  await say(USER, "/start");

  const reply = last("sendMessage", USER);
  assert.match(reply.text, /xush kelibsiz/);
  assert.match(reply.text, /obuna bo'lishingiz shart/);
  assert.equal(buttons(reply)[0].url, "https://t.me/kanal");
  assert.ok(hasCallback(reply, "check_sub"));
});

test("obuna bo'lmagan foydalanuvchiga menyu va kurslar yopiq", async () => {
  memberStatus = "left";
  const id = db.createCourse({ title: "Kurs", description: "d", price: 1000 });

  await say(USER, "📚 Kurslar");
  assert.match(last("sendMessage", USER).text, /obuna bo'lishingiz shart/);

  await press(USER, `paid:${id}`);
  assert.equal(db.stats().pending, 0);
});

test("«Obuna bo'ldim»: obuna bo'lmasa ogohlantiradi, bo'lsa menyuni ochadi", async () => {
  memberStatus = "left";
  await press(USER, "check_sub");
  assert.equal(last("answerCallbackQuery").show_alert, true);
  assert.equal(sent("sendMessage", USER).length, 0);

  memberStatus = "member";
  await press(USER, "check_sub");
  assert.ok(last("sendMessage", USER).reply_markup.keyboard);
});

test("kanalni tekshirish xatosida foydalanuvchi o'tkazilmaydi", async () => {
  bot.api.config.use(async (prev, method, payload, signal) =>
    method === "getChatMember"
      ? { ok: false, error_code: 400, description: "Bad Request: member list is inaccessible" }
      : prev(method, payload, signal),
  );
  await say(USER, "/start");
  assert.match(last("sendMessage", USER).text, /obuna bo'lishingiz shart/);
});

test("admin kursni qo'shadi, foydalanuvchi uni ko'radi", async () => {
  await press(ADMIN, "adm:add");
  await say(ADMIN, "Node.js <kurs>");
  await say(ADMIN, "To'liq kurs");
  await say(ADMIN, "abc");
  assert.match(last("sendMessage", ADMIN).text, /faqat raqam/);
  await say(ADMIN, "150 000");
  await message(ADMIN, { video: { file_id: "V1", file_unique_id: "u", width: 1, height: 1, duration: 1 } });
  await press(ADMIN, "adm:done");

  const [course] = db.listActiveCourses();
  assert.equal(course.title, "Node.js <kurs>");
  assert.equal(course.price, 150000);
  assert.equal(db.getVideos(course.id)[0].file_id, "V1");

  await say(USER, "📚 Kurslar");
  assert.equal(buttons(last("sendMessage", USER))[0].text, "Node.js <kurs> — 150 000 so'm");

  await press(USER, `course:${course.id}`);
  assert.match(last("editMessageText").text, /Node\.js &lt;kurs&gt;/);
});

test("admin karta va username kiritadi, noto'g'risi rad etiladi", async () => {
  await press(ADMIN, "adm:set:card");
  await say(ADMIN, "1234");
  assert.match(last("sendMessage", ADMIN).text, /16 ta raqam/);
  assert.equal(db.getSetting("card_number"), null);
  await say(ADMIN, "8600 1234 1234 1234");
  assert.equal(db.getSetting("card_number"), "8600123412341234");

  await press(ADMIN, "adm:set:admin");
  await say(ADMIN, "@real_admin");
  assert.equal(db.getSetting("admin_username"), "real_admin");
});

test("oddiy foydalanuvchi admin panelni ocha olmaydi", async () => {
  await say(USER, "/admin");
  assert.doesNotMatch(last("sendMessage", USER).text, /Admin panel/);

  await press(USER, "adm:delyes:1");
  await press(USER, "adm:set:card");
  await say(USER, "8600123412341234");
  assert.equal(db.getSetting("card_number"), null);
});

test("to'lov oynasida karta, summa va admin username ko'rsatiladi", async () => {
  setPaymentSettings();
  const id = db.createCourse({ title: "Kurs", description: "d", price: 150000 });

  await press(USER, `buy:${id}`);
  const screen = last("editMessageText");
  assert.match(screen.text, /8600 1234 1234 1234/);
  assert.match(screen.text, /150 000 so'm/);
  assert.match(screen.text, /@real_admin/);
  assert.ok(hasCallback(screen, `paid:${id}`));
});

test("karta kiritilmagan bo'lsa to'lov oynasi ochilmaydi", async () => {
  const id = db.createCourse({ title: "Kurs", description: "d", price: 1000 });
  await press(USER, `buy:${id}`);
  assert.equal(last("answerCallbackQuery").show_alert, true);
  assert.equal(sent("editMessageText").length, 0);
});

test("«To'ladim» adminga tasdiqlash so'rovini yuboradi, takroriy bosish yangi so'rov ochmaydi", async () => {
  setPaymentSettings();
  const id = db.createCourse({ title: "Kurs", description: "d", price: 1000 });

  await press(USER, `paid:${id}`);
  await press(USER, `paid:${id}`);

  assert.equal(db.stats().pending, 1);
  const toAdmin = sent("sendMessage", ADMIN);
  assert.equal(toAdmin.length, 1);
  assert.match(toAdmin[0].payload.text, /Ali &lt;b&gt;/);
  assert.ok(hasCallback(toAdmin[0].payload, "approve:1"));
  assert.ok(hasCallback(toAdmin[0].payload, "reject:1"));
  assert.match(last("editMessageText").text, /@real_admin/);
});

test("tasdiqlash videoni himoyalangan holda yuboradi va faqat bir marta ishlaydi", async () => {
  setPaymentSettings();
  const id = db.createCourse({ title: "Kurs", description: "d", price: 1000, videos: [video] });
  await press(USER, `paid:${id}`);

  await press(ADMIN, "approve:1");
  await press(ADMIN, "approve:1");
  await press(ADMIN, "reject:1");

  assert.equal(db.getOrder(1).status, "approved");
  assert.equal(db.getOrder(1).decided_by, ADMIN);
  const videos = sent("sendVideo", USER);
  assert.equal(videos.length, 1);
  assert.equal(videos[0].payload.protect_content, true);
  assert.equal(db.hasPurchased(USER, id), true);

  await press(USER, `paid:${id}`);
  assert.equal(db.stats().pending, 0);
});

test("foydalanuvchi o'z to'lovini tasdiqlay olmaydi", async () => {
  const id = db.createCourse({ title: "Kurs", description: "d", price: 1000, videos: [video] });
  await press(USER, `paid:${id}`);

  await press(USER, "approve:1");

  assert.equal(db.getOrder(1).status, "pending");
  assert.equal(sent("sendVideo", USER).length, 0);
});

test("bekor qilingan to'lovdan keyin foydalanuvchi xabar oladi va qayta so'rov yubora oladi", async () => {
  setPaymentSettings();
  const id = db.createCourse({ title: "Kurs", description: "d", price: 1000, videos: [video] });
  await press(USER, `paid:${id}`);

  await press(ADMIN, "reject:1");

  assert.equal(db.getOrder(1).status, "rejected");
  assert.equal(sent("sendVideo", USER).length, 0);
  assert.match(last("sendMessage", USER).text, /tasdiqlanmadi/);
  await press(USER, `watch:${id}`);
  assert.equal(sent("sendVideo", USER).length, 0);

  await press(USER, `paid:${id}`);
  assert.equal(db.stats().pending, 1);
});

test("foydalanuvchi botni bloklagan bo'lsa ham tasdiqlash adminda xatoga olib kelmaydi", async () => {
  const id = db.createCourse({ title: "Kurs", description: "d", price: 1000, videos: [video] });
  await press(USER, `paid:${id}`);
  blockedChats.add(USER);

  await press(ADMIN, "approve:1");

  assert.equal(db.getOrder(1).status, "approved");
  assert.match(last("sendMessage", ADMIN).text, /yuborib bo'lmadi/);
});

test("o'chirilgan kurs sotilmaydi, lekin xaridor uni ola oladi", async () => {
  const id = db.createCourse({ title: "Kurs", description: "d", price: 1000, videos: [video] });
  await press(USER, `paid:${id}`);
  await press(ADMIN, "approve:1");
  calls.length = 0;

  await press(ADMIN, `adm:delyes:${id}`);
  assert.equal(db.listActiveCourses().length, 0);

  await press(USER, `watch:${id}`);
  assert.equal(sent("sendVideo", USER).length, 1);

  await press(300, `paid:${id}`);
  assert.equal(db.stats().pending, 0);
});

test("videosiz kurs tasdiqlansa admin ogohlantiriladi", async () => {
  const id = db.createCourse({ title: "Kurs", description: "d", price: 1000 });
  await press(USER, `paid:${id}`);

  await press(ADMIN, "approve:1");

  assert.match(last("sendMessage", USER).text, /alohida yuboradi/);
  assert.match(last("sendMessage", ADMIN).text, /video yo'q/);
});
