import { GrammyError, InlineKeyboard, Keyboard } from "grammy";

export const MENU = {
  courses: "📚 Kurslar",
  myCourses: "🎓 Mening kurslarim",
  contact: "👨‍💼 Admin bilan bog'lanish",
  admin: "⚙️ Admin panel",
};

export const SETTING = { card: "card_number", holder: "card_holder", admin: "admin_username" };

export const esc = (text) =>
  String(text).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

export const formatPrice = (n) => `${String(n).replace(/\B(?=(\d{3})+(?!\d))/g, " ")} so'm`;

export const formatCard = (digits) => digits.replace(/(\d{4})(?=\d)/g, "$1 ");

export const formatDate = (unixSeconds) =>
  new Date(unixSeconds * 1000).toLocaleString("en-GB", { timeZone: "Asia/Tashkent" });

export function mainMenu(isAdmin) {
  const kb = new Keyboard().text(MENU.courses).text(MENU.myCourses).row().text(MENU.contact);
  if (isAdmin) kb.row().text(MENU.admin);
  return kb.resized();
}

/** Tugma bosilganda xabarni tahrirlaydi, aks holda yangi xabar yuboradi. */
export async function showScreen(ctx, text, replyMarkup) {
  if (ctx.callbackQuery) {
    try {
      await ctx.editMessageText(text, { reply_markup: replyMarkup });
      return;
    } catch (err) {
      if (!(err instanceof GrammyError)) throw err;
      if (err.description.includes("message is not modified")) return;
    }
  }
  await ctx.reply(text, { reply_markup: replyMarkup });
}

export function orderCard(order) {
  const user = esc(order.user_first_name);
  const username = order.user_username ? ` (@${esc(order.user_username)})` : "";
  return [
    `🧾 <b>To'lov so'rovi #${order.id}</b>`,
    "",
    `👤 Foydalanuvchi: <a href="tg://user?id=${order.user_id}">${user}</a>${username}`,
    `🆔 ID: <code>${order.user_id}</code>`,
    `📚 Kurs: ${esc(order.course_title)}`,
    `💰 Summa: ${formatPrice(order.amount)}`,
    `🕒 Vaqt: ${formatDate(order.created_at)}`,
  ].join("\n");
}

export const decisionKeyboard = (orderId) =>
  new InlineKeyboard()
    .text("✅ Tasdiqlash", `approve:${orderId}`)
    .text("❌ Bekor qilish", `reject:${orderId}`);

/** Kurs videolarini yuboradi. Himoyalangan: uzatib (forward) yoki saqlab bo'lmaydi. */
export async function deliverCourse(api, userId, course, videos) {
  for (const [index, video] of videos.entries()) {
    const caption = esc(video.caption || `${course.title} — ${index + 1}-dars`);
    const options = { caption, protect_content: true };
    if (video.kind === "video") await api.sendVideo(userId, video.file_id, options);
    else await api.sendDocument(userId, video.file_id, options);
  }
}
