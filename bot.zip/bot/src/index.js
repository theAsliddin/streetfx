import { createBot } from "./bot.js";
import { loadConfig } from "./config.js";
import { openDb } from "./db.js";

async function main() {
  try {
    process.loadEnvFile();
  } catch (err) {
    if (err.code !== "ENOENT") throw err;
  }

  const config = loadConfig();
  const db = openDb(config.dbPath);
  const bot = createBot({ config, db });

  await bot.init();

  // Bot kanal admini bo'lmasa, obunani tekshira olmaydi va hech kim botdan foydalana olmaydi.
  const self = await bot.api.getChatMember(config.channelId, bot.botInfo.id).catch((err) => {
    throw new Error(`Botni ${config.channelId} kanaliga admin qilib qo'shing (${err.message})`);
  });
  if (self.status !== "administrator") {
    throw new Error(`Botni ${config.channelId} kanaliga admin qilib qo'shing (hozirgi holati: ${self.status})`);
  }

  await bot.api.setMyCommands([{ command: "start", description: "Botni ishga tushirish" }]);

  const shutdown = async () => {
    await bot.stop();
    db.close();
  };
  process.once("SIGINT", shutdown);
  process.once("SIGTERM", shutdown);

  await bot.start({
    allowed_updates: ["message", "callback_query"],
    onStart: (me) => console.log(`@${me.username} ishga tushdi`),
  });
}

main().catch((err) => {
  console.error(`Xato: ${err.message}`);
  process.exit(1);
});
