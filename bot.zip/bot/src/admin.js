import { Composer, InlineKeyboard } from "grammy";
import {
  MENU,
  SETTING,
  decisionKeyboard,
  deliverCourse,
  esc,
  formatCard,
  formatPrice,
  orderCard,
  showScreen,
} from "./shared.js";

const MAX_TITLE = 100;
const MAX_DESCRIPTION = 3000;
const MAX_HOLDER = 64;

const parsePrice = (text) => {
  const digits = text.replace(/[\s,.]/g, "");
  if (!/^\d+$/.test(digits)) return null;
  const price = Number(digits);
  return price > 0 && Number.isSafeInteger(price) ? price : null;
};

const FIELD_PROMPTS = {
  title: `Yangi nomni yuboring (${MAX_TITLE} belgigacha):`,
  description: `Yangi tavsifni yuboring (${MAX_DESCRIPTION} belgigacha):`,
  price: "Yangi narxni so'mda yuboring (masalan: 150000):",
};

const SETTING_PROMPTS = {
  card: "💳 Karta raqamini yuboring (16 ta raqam):",
  holder: `👤 Karta egasining ism-familiyasini yuboring (${MAX_HOLDER} belgigacha):`,
  admin: "👨‍💼 Skrinshot qabul qiladigan admin username'ini yuboring (masalan: @admin_username):",
};

/** Har bir maydon uchun: { value } yoki { error } qaytaradi. */
const validators = {
  title: (t) => (t.length <= MAX_TITLE ? { value: t } : { error: `Nom ${MAX_TITLE} belgidan oshmasin.` }),
  description: (t) =>
    t.length <= MAX_DESCRIPTION ? { value: t } : { error: `Tavsif ${MAX_DESCRIPTION} belgidan oshmasin.` },
  price: (t) => {
    const value = parsePrice(t);
    return value ? { value } : { error: "Narxni faqat raqam bilan yuboring (masalan: 150000)." };
  },
  card: (t) => {
    const value = t.replace(/[\s-]/g, "");
    return /^\d{16}$/.test(value) ? { value } : { error: "Karta raqami 16 ta raqamdan iborat bo'lishi kerak." };
  },
  holder: (t) => (t.length <= MAX_HOLDER ? { value: t } : { error: `${MAX_HOLDER} belgidan oshmasin.` }),
  admin: (t) => {
    const value = t.replace(/^@/, "");
    return /^[A-Za-z0-9_]{4,32}$/.test(value)
      ? { value }
      : { error: "Username noto'g'ri. Masalan: @admin_username" };
  },
};

const panelKeyboard = () =>
  new InlineKeyboard()
    .text("➕ Kurs qo'shish", "adm:add")
    .row()
    .text("📋 Kurslar", "adm:courses")
    .text("💳 To'lov sozlamalari", "adm:settings")
    .row()
    .text("⏳ Kutilayotgan to'lovlar", "adm:pending")
    .row()
    .text("📊 Statistika", "adm:stats");

const backToPanel = () => new InlineKeyboard().text("⬅️ Admin panel", "adm:menu");

export function adminHandlers({ config, db }) {
  const composer = new Composer();
  const admin = composer.filter((ctx) => config.adminIds.includes(ctx.from.id));

  // Bosqichma-bosqich kiritish holati. Xotirada: bot qayta ishga tushsa, faqat tugallanmagan kiritish yo'qoladi.
  const wizard = new Map();
  const menuLabels = new Set(Object.values(MENU));

  const renderPanel = (ctx) => showScreen(ctx, "⚙️ <b>Admin panel</b>", panelKeyboard());

  const renderCourses = (ctx) => {
    const courses = db.listActiveCourses();
    const kb = new InlineKeyboard();
    for (const c of courses) kb.text(c.title, `adm:course:${c.id}`).row();
    kb.text("➕ Kurs qo'shish", "adm:add").row().text("⬅️ Admin panel", "adm:menu");
    return showScreen(ctx, courses.length ? "📋 <b>Kurslar:</b>" : "Hozircha kurslar yo'q.", kb);
  };

  const renderCourse = (ctx, id) => {
    const course = db.getCourse(id);
    if (!course?.is_active) return renderCourses(ctx);
    const videoCount = db.getVideos(id).length;
    return showScreen(
      ctx,
      [
        `📚 <b>${esc(course.title)}</b>`,
        "",
        esc(course.description),
        "",
        `💰 Narxi: ${formatPrice(course.price)}`,
        `🎬 Videolar: ${videoCount} ta`,
      ].join("\n"),
      new InlineKeyboard()
        .text("✏️ Nom", `adm:edit:${id}:title`)
        .text("✏️ Tavsif", `adm:edit:${id}:description`)
        .text("✏️ Narx", `adm:edit:${id}:price`)
        .row()
        .text("🎬 Video qo'shish", `adm:videos:${id}`)
        .text("🧹 Videolarni tozalash", `adm:clear:${id}`)
        .row()
        .text("🗑 Kursni o'chirish", `adm:del:${id}`)
        .row()
        .text("⬅️ Kurslar", "adm:courses"),
    );
  };

  const renderSettings = (ctx) => {
    const card = db.getSetting(SETTING.card);
    const holder = db.getSetting(SETTING.holder);
    const username = db.getSetting(SETTING.admin);
    return showScreen(
      ctx,
      [
        "💳 <b>To'lov sozlamalari</b>",
        "",
        `Karta raqami: ${card ? `<code>${formatCard(card)}</code>` : "kiritilmagan"}`,
        `Karta egasi: ${holder ? esc(holder) : "kiritilmagan"}`,
        `Admin username: ${username ? `@${esc(username)}` : "kiritilmagan"}`,
      ].join("\n"),
      new InlineKeyboard()
        .text("💳 Karta raqami", "adm:set:card")
        .text("👤 Karta egasi", "adm:set:holder")
        .row()
        .text("👨‍💼 Admin username", "adm:set:admin")
        .row()
        .text("⬅️ Admin panel", "adm:menu"),
    );
  };

  const videosPrompt = (saved) =>
    `🎬 Video darslarni birma-bir yuboring (video yoki fayl ko'rinishida).\n` +
    `Qabul qilindi: ${saved} ta\n\nTugatgach, «✅ Tayyor» tugmasini bosing.`;
  const videosKeyboard = () => new InlineKeyboard().text("✅ Tayyor", "adm:done").row().text("❌ Bekor qilish", "adm:menu");

  // Yangi tugma bosilsa tugallanmagan kiritish bekor qilinadi («Tayyor» bundan mustasno).
  admin.callbackQuery(/^adm:/, async (ctx, next) => {
    if (ctx.callbackQuery.data !== "adm:done") wizard.delete(ctx.from.id);
    await next();
  });

  admin.on("message", async (ctx, next) => {
    const state = wizard.get(ctx.from.id);
    if (!state) return next();

    const text = ctx.message.text;
    if (text === "/cancel") {
      wizard.delete(ctx.from.id);
      await ctx.reply("❌ Bekor qilindi.", { reply_markup: backToPanel() });
      return;
    }
    if (text?.startsWith("/") || menuLabels.has(text)) {
      wizard.delete(ctx.from.id);
      return next();
    }

    if (state.step === "videos") {
      const video = ctx.message.video;
      const document = ctx.message.document;
      const file = video ?? document;
      if (!file) {
        await ctx.reply(videosPrompt(state.videos.length), { reply_markup: videosKeyboard() });
        return;
      }
      state.videos.push({
        file_id: file.file_id,
        kind: video ? "video" : "document",
        caption: ctx.message.caption ?? null,
      });
      await ctx.reply(videosPrompt(state.videos.length), { reply_markup: videosKeyboard() });
      return;
    }

    if (!text) {
      await ctx.reply("Iltimos, matn yuboring (bekor qilish: /cancel).");
      return;
    }

    const result = validators[state.field](text.trim());
    if (result.error) {
      await ctx.reply(`⚠️ ${result.error}\nQaytadan yuboring (bekor qilish: /cancel).`);
      return;
    }

    if (state.step === "setting") {
      db.setSetting(SETTING[state.field], String(result.value));
      wizard.delete(ctx.from.id);
      await ctx.reply("✅ Saqlandi.");
      await renderSettings(ctx);
      return;
    }

    if (state.step === "edit") {
      db.updateCourseField(state.courseId, state.field, result.value);
      wizard.delete(ctx.from.id);
      await ctx.reply("✅ Saqlandi.");
      await renderCourse(ctx, state.courseId);
      return;
    }

    // Yangi kurs: nom → tavsif → narx → videolar.
    state.draft[state.field] = result.value;
    if (state.field === "title") {
      state.field = "description";
      await ctx.reply(`2/4. Kurs haqida ma'lumot yuboring (${MAX_DESCRIPTION} belgigacha):`);
    } else if (state.field === "description") {
      state.field = "price";
      await ctx.reply("3/4. Kurs narxini so'mda yuboring (masalan: 150000):");
    } else {
      wizard.set(ctx.from.id, { step: "videos", draft: state.draft, videos: [] });
      await ctx.reply(`4/4. ${videosPrompt(0)}`, { reply_markup: videosKeyboard() });
    }
  });

  admin.command("admin", renderPanel);
  admin.hears(MENU.admin, renderPanel);

  admin.callbackQuery("adm:menu", async (ctx) => {
    await ctx.answerCallbackQuery();
    await renderPanel(ctx);
  });

  admin.callbackQuery("adm:add", async (ctx) => {
    await ctx.answerCallbackQuery();
    wizard.set(ctx.from.id, { step: "new", field: "title", draft: {} });
    await ctx.reply(`➕ <b>Yangi kurs</b>\n\n1/4. Kurs nomini yuboring (${MAX_TITLE} belgigacha):\n\nBekor qilish: /cancel`);
  });

  admin.callbackQuery("adm:done", async (ctx) => {
    const state = wizard.get(ctx.from.id);
    if (state?.step !== "videos") {
      await ctx.answerCallbackQuery({ text: "Bu amal eskirgan" });
      return;
    }
    wizard.delete(ctx.from.id);
    await ctx.answerCallbackQuery({ text: "✅ Saqlandi" });

    const courseId = state.draft
      ? db.createCourse({ ...state.draft, videos: state.videos })
      : state.courseId;
    if (!state.draft) db.addVideos(courseId, state.videos);
    await renderCourse(ctx, courseId);
  });

  admin.callbackQuery("adm:courses", async (ctx) => {
    await ctx.answerCallbackQuery();
    await renderCourses(ctx);
  });

  admin.callbackQuery(/^adm:course:(\d+)$/, async (ctx) => {
    await ctx.answerCallbackQuery();
    await renderCourse(ctx, Number(ctx.match[1]));
  });

  admin.callbackQuery(/^adm:edit:(\d+):(title|description|price)$/, async (ctx) => {
    const [, id, field] = ctx.match;
    await ctx.answerCallbackQuery();
    wizard.set(ctx.from.id, { step: "edit", courseId: Number(id), field });
    await ctx.reply(`${FIELD_PROMPTS[field]}\n\nBekor qilish: /cancel`);
  });

  admin.callbackQuery(/^adm:videos:(\d+)$/, async (ctx) => {
    await ctx.answerCallbackQuery();
    wizard.set(ctx.from.id, { step: "videos", courseId: Number(ctx.match[1]), videos: [] });
    await ctx.reply(videosPrompt(0), { reply_markup: videosKeyboard() });
  });

  admin.callbackQuery(/^adm:clear:(\d+)$/, async (ctx) => {
    const id = Number(ctx.match[1]);
    await ctx.answerCallbackQuery();
    await showScreen(
      ctx,
      "🧹 Bu kursning barcha videolari o'chirilsinmi?",
      new InlineKeyboard().text("Ha, o'chirish", `adm:clearyes:${id}`).text("Yo'q", `adm:course:${id}`),
    );
  });

  admin.callbackQuery(/^adm:clearyes:(\d+)$/, async (ctx) => {
    const id = Number(ctx.match[1]);
    db.clearVideos(id);
    await ctx.answerCallbackQuery({ text: "Videolar o'chirildi" });
    await renderCourse(ctx, id);
  });

  admin.callbackQuery(/^adm:del:(\d+)$/, async (ctx) => {
    const id = Number(ctx.match[1]);
    await ctx.answerCallbackQuery();
    await showScreen(
      ctx,
      "🗑 Kurs ro'yxatdan olib tashlansinmi?\n\nUni oldin sotib olganlar videolarni olishda davom etadi.",
      new InlineKeyboard().text("Ha, o'chirish", `adm:delyes:${id}`).text("Yo'q", `adm:course:${id}`),
    );
  });

  admin.callbackQuery(/^adm:delyes:(\d+)$/, async (ctx) => {
    db.hideCourse(Number(ctx.match[1]));
    await ctx.answerCallbackQuery({ text: "Kurs o'chirildi" });
    await renderCourses(ctx);
  });

  admin.callbackQuery("adm:settings", async (ctx) => {
    await ctx.answerCallbackQuery();
    await renderSettings(ctx);
  });

  admin.callbackQuery(/^adm:set:(card|holder|admin)$/, async (ctx) => {
    const field = ctx.match[1];
    await ctx.answerCallbackQuery();
    wizard.set(ctx.from.id, { step: "setting", field });
    await ctx.reply(`${SETTING_PROMPTS[field]}\n\nBekor qilish: /cancel`);
  });

  admin.callbackQuery("adm:pending", async (ctx) => {
    await ctx.answerCallbackQuery();
    const orders = db.listPendingOrders();
    if (orders.length === 0) {
      await showScreen(ctx, "✅ Kutilayotgan to'lovlar yo'q.", backToPanel());
      return;
    }
    for (const order of orders) {
      await ctx.reply(orderCard(order), { reply_markup: decisionKeyboard(order.id) });
    }
  });

  admin.callbackQuery("adm:stats", async (ctx) => {
    await ctx.answerCallbackQuery();
    const s = db.stats();
    await showScreen(
      ctx,
      [
        "📊 <b>Statistika</b>",
        "",
        `👥 Foydalanuvchilar: ${s.users}`,
        `📚 Kurslar: ${s.courses}`,
        `⏳ Kutilayotgan to'lovlar: ${s.pending}`,
        `✅ Tasdiqlangan sotuvlar: ${s.approved}`,
        `💰 Jami tushum: ${formatPrice(s.revenue)}`,
      ].join("\n"),
      backToPanel(),
    );
  });

  const closeOrderCard = (ctx, order, statusLine) =>
    showScreen(ctx, `${orderCard(order)}\n\n${statusLine}`);

  admin.callbackQuery(/^approve:(\d+)$/, async (ctx) => {
    const orderId = Number(ctx.match[1]);
    if (!db.decideOrder(orderId, "approved", ctx.from.id)) {
      await ctx.answerCallbackQuery({ text: "Bu so'rov allaqachon ko'rib chiqilgan", show_alert: true });
      await ctx.editMessageReplyMarkup().catch(() => {});
      return;
    }
    await ctx.answerCallbackQuery({ text: "✅ Tasdiqlandi" });

    const order = db.getOrder(orderId);
    const course = db.getCourse(order.course_id);
    const videos = db.getVideos(course.id);
    await closeOrderCard(ctx, order, `✅ <b>Tasdiqlandi:</b> ${esc(ctx.from.first_name)}`);

    try {
      await ctx.api.sendMessage(
        order.user_id,
        `🎉 <b>To'lovingiz tasdiqlandi!</b>\n\n📚 Kurs: ${esc(course.title)}\n` +
          (videos.length
            ? "Video darslar quyida yuboriladi. Keyinchalik ularni «🎓 Mening kurslarim» bo'limidan qayta olishingiz mumkin."
            : "Kurs materiallarini admin sizga alohida yuboradi."),
      );
      await deliverCourse(ctx.api, order.user_id, course, videos);
      if (videos.length === 0) {
        await ctx.reply("⚠️ Bu kursda video yo'q. Materiallarni foydalanuvchiga o'zingiz yuboring.");
      }
    } catch (err) {
      console.error(`Buyurtma #${orderId} yetkazilmadi:`, err.message);
      await ctx.reply(
        `⚠️ Buyurtma #${orderId} tasdiqlandi, lekin kursni foydalanuvchiga yuborib bo'lmadi ` +
          "(botni bloklagan bo'lishi mumkin). U «🎓 Mening kurslarim» bo'limidan qayta olishi mumkin.",
      );
    }
  });

  admin.callbackQuery(/^reject:(\d+)$/, async (ctx) => {
    const orderId = Number(ctx.match[1]);
    if (!db.decideOrder(orderId, "rejected", ctx.from.id)) {
      await ctx.answerCallbackQuery({ text: "Bu so'rov allaqachon ko'rib chiqilgan", show_alert: true });
      await ctx.editMessageReplyMarkup().catch(() => {});
      return;
    }
    await ctx.answerCallbackQuery({ text: "❌ Bekor qilindi" });

    const order = db.getOrder(orderId);
    await closeOrderCard(ctx, order, `❌ <b>Bekor qilindi:</b> ${esc(ctx.from.first_name)}`);

    const username = db.getSetting(SETTING.admin);
    await ctx.api
      .sendMessage(
        order.user_id,
        `❌ <b>To'lovingiz tasdiqlanmadi.</b>\n\n📚 Kurs: ${esc(order.course_title)}\n` +
          (username ? `Savollar bo'lsa, adminga murojaat qiling: @${esc(username)}` : ""),
      )
      .catch((err) => console.error(`Buyurtma #${orderId} rad xabari yuborilmadi:`, err.message));
  });

  return composer;
}
