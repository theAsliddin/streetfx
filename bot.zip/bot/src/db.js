import { mkdirSync } from "node:fs";
import { dirname } from "node:path";
import { DatabaseSync } from "node:sqlite";

const SCHEMA = `
  CREATE TABLE IF NOT EXISTS users (
    id         INTEGER PRIMARY KEY,
    first_name TEXT NOT NULL,
    username   TEXT,
    created_at INTEGER NOT NULL DEFAULT (unixepoch())
  );

  CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS courses (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    title       TEXT NOT NULL,
    description TEXT NOT NULL,
    price       INTEGER NOT NULL,
    is_active   INTEGER NOT NULL DEFAULT 1,
    created_at  INTEGER NOT NULL DEFAULT (unixepoch())
  );

  CREATE TABLE IF NOT EXISTS course_videos (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    course_id INTEGER NOT NULL REFERENCES courses(id),
    file_id   TEXT NOT NULL,
    kind      TEXT NOT NULL CHECK (kind IN ('video', 'document')),
    caption   TEXT
  );

  CREATE TABLE IF NOT EXISTS orders (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id),
    course_id  INTEGER NOT NULL REFERENCES courses(id),
    amount     INTEGER NOT NULL,
    status     TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
    created_at INTEGER NOT NULL DEFAULT (unixepoch()),
    decided_at INTEGER,
    decided_by INTEGER
  );

  CREATE UNIQUE INDEX IF NOT EXISTS orders_one_pending
    ON orders(user_id, course_id) WHERE status = 'pending';
`;

const ORDER_SELECT = `
  SELECT o.*, c.title AS course_title, u.first_name AS user_first_name, u.username AS user_username
  FROM orders o
  JOIN courses c ON c.id = o.course_id
  JOIN users u ON u.id = o.user_id
`;

const EDITABLE_COURSE_FIELDS = new Set(["title", "description", "price"]);

export function openDb(path) {
  if (path !== ":memory:") mkdirSync(dirname(path), { recursive: true });

  const db = new DatabaseSync(path);
  db.exec("PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;");
  db.exec(SCHEMA);

  const addVideos = (courseId, videos) => {
    const insert = db.prepare(
      "INSERT INTO course_videos (course_id, file_id, kind, caption) VALUES (?, ?, ?, ?)",
    );
    for (const v of videos) insert.run(courseId, v.file_id, v.kind, v.caption ?? null);
  };

  return {
    close: () => db.close(),

    upsertUser({ id, first_name, username }) {
      db.prepare(
        `INSERT INTO users (id, first_name, username) VALUES (?, ?, ?)
         ON CONFLICT(id) DO UPDATE SET first_name = excluded.first_name, username = excluded.username`,
      ).run(id, first_name, username ?? null);
    },

    getSetting(key) {
      return db.prepare("SELECT value FROM settings WHERE key = ?").get(key)?.value ?? null;
    },

    setSetting(key, value) {
      db.prepare(
        `INSERT INTO settings (key, value) VALUES (?, ?)
         ON CONFLICT(key) DO UPDATE SET value = excluded.value`,
      ).run(key, value);
    },

    createCourse({ title, description, price, videos = [] }) {
      db.exec("BEGIN");
      try {
        const { lastInsertRowid } = db
          .prepare("INSERT INTO courses (title, description, price) VALUES (?, ?, ?)")
          .run(title, description, price);
        const id = Number(lastInsertRowid);
        addVideos(id, videos);
        db.exec("COMMIT");
        return id;
      } catch (err) {
        db.exec("ROLLBACK");
        throw err;
      }
    },

    getCourse(id) {
      return db.prepare("SELECT * FROM courses WHERE id = ?").get(id);
    },

    listActiveCourses() {
      return db.prepare("SELECT * FROM courses WHERE is_active = 1 ORDER BY id").all();
    },

    updateCourseField(id, field, value) {
      if (!EDITABLE_COURSE_FIELDS.has(field)) throw new Error(`Noma'lum maydon: ${field}`);
      db.prepare(`UPDATE courses SET ${field} = ? WHERE id = ?`).run(value, id);
    },

    // Kurs o'chirilmaydi, faqat yashiriladi: uni sotib olganlar videolarni olishda davom etadi.
    hideCourse(id) {
      db.prepare("UPDATE courses SET is_active = 0 WHERE id = ?").run(id);
    },

    addVideos,

    getVideos(courseId) {
      return db.prepare("SELECT * FROM course_videos WHERE course_id = ? ORDER BY id").all(courseId);
    },

    clearVideos(courseId) {
      db.prepare("DELETE FROM course_videos WHERE course_id = ?").run(courseId);
    },

    hasPurchased(userId, courseId) {
      return Boolean(
        db
          .prepare("SELECT 1 FROM orders WHERE user_id = ? AND course_id = ? AND status = 'approved'")
          .get(userId, courseId),
      );
    },

    listPurchasedCourses(userId) {
      return db
        .prepare(
          `SELECT DISTINCT c.* FROM courses c
           JOIN orders o ON o.course_id = c.id
           WHERE o.user_id = ? AND o.status = 'approved'
           ORDER BY c.id`,
        )
        .all(userId);
    },

    /** Yangi buyurtma ID sini qaytaradi; shu kurs bo'yicha kutilayotgan buyurtma bo'lsa null. */
    createOrder(userId, courseId, amount) {
      const { changes, lastInsertRowid } = db
        .prepare("INSERT OR IGNORE INTO orders (user_id, course_id, amount) VALUES (?, ?, ?)")
        .run(userId, courseId, amount);
      return Number(changes) === 1 ? Number(lastInsertRowid) : null;
    },

    getOrder(id) {
      return db.prepare(`${ORDER_SELECT} WHERE o.id = ?`).get(id);
    },

    listPendingOrders(limit = 20) {
      return db.prepare(`${ORDER_SELECT} WHERE o.status = 'pending' ORDER BY o.id LIMIT ?`).all(limit);
    },

    /** Faqat kutilayotgan buyurtmani o'zgartiradi, shuning uchun qaror ikki marta qabul qilinmaydi. */
    decideOrder(id, status, adminId) {
      const { changes } = db
        .prepare(
          `UPDATE orders SET status = ?, decided_by = ?, decided_at = unixepoch()
           WHERE id = ? AND status = 'pending'`,
        )
        .run(status, adminId, id);
      return Number(changes) === 1;
    },

    stats() {
      const count = (sql) => db.prepare(sql).get().n;
      return {
        users: count("SELECT COUNT(*) AS n FROM users"),
        courses: count("SELECT COUNT(*) AS n FROM courses WHERE is_active = 1"),
        pending: count("SELECT COUNT(*) AS n FROM orders WHERE status = 'pending'"),
        approved: count("SELECT COUNT(*) AS n FROM orders WHERE status = 'approved'"),
        revenue: count("SELECT COALESCE(SUM(amount), 0) AS n FROM orders WHERE status = 'approved'"),
      };
    },
  };
}
