import { autoRetry } from "@grammyjs/auto-retry";
import { Bot } from "grammy";
import { adminHandlers } from "./admin.js";
import { subscriptionGate, userHandlers } from "./user.js";

export function createBot({ config, db, botInfo }) {
  const bot = new Bot(config.botToken, { botInfo });

  bot.api.config.use(autoRetry());
  bot.api.config.use((prev, method, payload, signal) =>
    prev(method, "text" in payload || "caption" in payload ? { parse_mode: "HTML", ...payload } : payload, signal),
  );

  // Bot faqat shaxsiy chatlarda ishlaydi.
  const pm = bot.chatType("private");

  pm.use(async (ctx, next) => {
    db.upsertUser(ctx.from);
    await next();
  });

  const deps = { config, db };
  pm.use(adminHandlers(deps));
  pm.use(subscriptionGate(deps));
  pm.use(userHandlers(deps));

  // Noma'lum yoki eskirgan tugmalarda "yuklanmoqda" belgisi osilib qolmasin.
  pm.on("callback_query", (ctx) => ctx.answerCallbackQuery());

  bot.catch(({ error, ctx }) => {
    console.error(`Update ${ctx.update.update_id} xatosi:`, error);
  });

  return bot;
}
