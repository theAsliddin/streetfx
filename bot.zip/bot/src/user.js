import { Composer, InlineKeyboard } from "grammy";
import {
  MENU,
  SETTING,
  decisionKeyboard,
  deliverCourse,
  esc,
  formatCard,
  formatPrice,
  mainMenu,
  orderCard,
  showScreen,
} from "./shared.js";

export async function isSubscribed(api, channelId, userId) {
  try {
    const member = await api.getChatMember(channelId, userId);
    return (
      ["creator", "administrator", "member"].includes(member.status) ||
      (member.status === "restricted" && member.is_member)
    );
  } catch (err) {
    console.error("Obunani tekshirib bo'lmadi:", err.message);
    return false;
  }
}

const welcome = (name) => `👋 Assalomu alaykum, <b>${esc(name)}</b>!\nBotimizga xush kelibsiz.`;

/** Kanalga obuna bo'lmagan foydalanuvchini keyingi handlerlarga o'tkazmaydi. */
export function subscriptionGate({ config }) {
  return async (ctx, next) => {
    if (config.adminIds.includes(ctx.from.id)) return next();
    if (ctx.callbackQuery?.data === "check_sub") return next();
    if (await isSubscribed(ctx.api, config.channelId, ctx.from.id)) return next();

    if (ctx.callbackQuery) {
      await ctx.answerCallbackQuery({ text: "Avval kanalga obuna bo'ling", show_alert: true });
    }
    await ctx.reply(
      `${welcome(ctx.from.first_name)}\n\n` +
        "📢 Botdan to'liq foydalanish uchun kanalimizga obuna bo'lishingiz shart. " +
        "Obuna bo'lgach, «✅ Obuna bo'ldim» tugmasini bosing.",
      {
        reply_markup: new InlineKeyboard()
          .url("📢 Kanalga obuna bo'lish", config.channelUrl)
          .row()
          .text("✅ Obuna bo'ldim", "check_sub"),
      },
    );
  };
}

export function userHandlers({ config, db }) {
  const user = new Composer();
  const isAdmin = (ctx) => config.adminIds.includes(ctx.from.id);
  const adminUsername = () => db.getSetting(SETTING.admin);

  const greet = (ctx) =>
    ctx.reply(`${welcome(ctx.from.first_name)}\n\nQuyidagi menyudan kerakli bo'limni tanlang 👇`, {
      reply_markup: mainMenu(isAdmin(ctx)),
    });

  const renderCatalog = (ctx) => {
    const courses = db.listActiveCourses();
    if (courses.length === 0) return showScreen(ctx, "😔 Hozircha kurslar qo'shilmagan.");
    const kb = new InlineKeyboard();
    for (const c of courses) kb.text(`${c.title} — ${formatPrice(c.price)}`, `course:${c.id}`).row();
    return showScreen(ctx, "📚 <b>Kurslar ro'yxati</b>\n\nKursni tanlang:", kb);
  };

  const courseUnavailable = (ctx) =>
    ctx.answerCallbackQuery({ text: "Bu kurs endi mavjud emas", show_alert: true });

  user.command("start", greet);

  user.callbackQuery("check_sub", async (ctx) => {
    if (!isAdmin(ctx) && !(await isSubscribed(ctx.api, config.channelId, ctx.from.id))) {
      await ctx.answerCallbackQuery({ text: "❌ Siz hali kanalga obuna bo'lmagansiz", show_alert: true });
      return;
    }
    await ctx.answerCallbackQuery({ text: "✅ Rahmat! Obuna tasdiqlandi" });
    await ctx.deleteMessage().catch(() => {});
    await greet(ctx);
  });

  user.hears(MENU.courses, renderCatalog);

  user.callbackQuery("catalog", async (ctx) => {
    await ctx.answerCallbackQuery();
    await renderCatalog(ctx);
  });

  user.hears(MENU.contact, async (ctx) => {
    const username = adminUsername();
    await ctx.reply(
      username
        ? `👨‍💼 Savollar va to'lov skrinshotlari uchun admin: @${esc(username)}`
        : "Admin ma'lumotlari hali kiritilmagan.",
    );
  });

  user.hears(MENU.myCourses, async (ctx) => {
    const courses = db.listPurchasedCourses(ctx.from.id);
    if (courses.length === 0) {
      await ctx.reply("Siz hali kurs sotib olmagansiz. «📚 Kurslar» bo'limiga o'ting.");
      return;
    }
    const kb = new InlineKeyboard();
    for (const c of courses) kb.text(c.title, `course:${c.id}`).row();
    await ctx.reply("🎓 <b>Sotib olgan kurslaringiz:</b>", { reply_markup: kb });
  });

  user.callbackQuery(/^course:(\d+)$/, async (ctx) => {
    const course = db.getCourse(Number(ctx.match[1]));
    const owned = course && db.hasPurchased(ctx.from.id, course.id);
    if (!course || (!course.is_active && !owned)) return courseUnavailable(ctx);
    await ctx.answerCallbackQuery();

    const kb = new InlineKeyboard();
    if (owned) kb.text("🎬 Videolarni olish", `watch:${course.id}`).row();
    else kb.text("💳 Sotib olish", `buy:${course.id}`).row();
    kb.text("⬅️ Orqaga", "catalog");

    const text = [
      `📚 <b>${esc(course.title)}</b>`,
      "",
      esc(course.description),
      "",
      owned ? "✅ Siz bu kursni sotib olgansiz" : `💰 Narxi: <b>${formatPrice(course.price)}</b>`,
    ].join("\n");
    await showScreen(ctx, text, kb);
  });

  user.callbackQuery(/^buy:(\d+)$/, async (ctx) => {
    const course = db.getCourse(Number(ctx.match[1]));
    if (!course?.is_active) return courseUnavailable(ctx);

    const card = db.getSetting(SETTING.card);
    if (!card) {
      await ctx.answerCallbackQuery({
        text: "To'lov ma'lumotlari hali kiritilmagan. Keyinroq urinib ko'ring.",
        show_alert: true,
      });
      return;
    }
    await ctx.answerCallbackQuery();

    const holder = db.getSetting(SETTING.holder);
    const username = adminUsername();
    const lines = [
      "💳 <b>To'lov ma'lumotlari</b>",
      "",
      `📚 Kurs: ${esc(course.title)}`,
      `💰 Summa: <b>${formatPrice(course.price)}</b>`,
      `🏦 Karta raqami: <code>${formatCard(card)}</code>`,
    ];
    if (holder) lines.push(`👤 Karta egasi: ${esc(holder)}`);
    lines.push("", "1️⃣ Ko'rsatilgan summani kartaga o'tkazing", "2️⃣ «✅ To'ladim» tugmasini bosing");
    if (username) lines.push(`3️⃣ To'lov skrinshotini adminga yuboring: @${esc(username)}`);

    await showScreen(
      ctx,
      lines.join("\n"),
      new InlineKeyboard().text("✅ To'ladim", `paid:${course.id}`).row().text("⬅️ Orqaga", `course:${course.id}`),
    );
  });

  user.callbackQuery(/^paid:(\d+)$/, async (ctx) => {
    const course = db.getCourse(Number(ctx.match[1]));
    if (!course?.is_active) return courseUnavailable(ctx);

    if (db.hasPurchased(ctx.from.id, course.id)) {
      await ctx.answerCallbackQuery({ text: "Siz bu kursni allaqachon sotib olgansiz", show_alert: true });
      return;
    }

    const orderId = db.createOrder(ctx.from.id, course.id, course.price);
    if (orderId === null) {
      await ctx.answerCallbackQuery({ text: "⏳ So'rovingiz admin tomonidan ko'rib chiqilmoqda", show_alert: true });
      return;
    }
    await ctx.answerCallbackQuery();

    const order = db.getOrder(orderId);
    for (const adminId of config.adminIds) {
      // Yuborilmasa ham so'rov yo'qolmaydi: u admin paneldagi «Kutilayotgan to'lovlar»da turadi.
      await ctx.api
        .sendMessage(adminId, orderCard(order), { reply_markup: decisionKeyboard(orderId) })
        .catch((err) => console.error(`Admin ${adminId} ga yuborilmadi:`, err.message));
    }

    const username = adminUsername();
    await showScreen(
      ctx,
      "⏳ <b>So'rovingiz adminga yuborildi.</b>\n\n" +
        "To'lov tasdiqlangach, sizga xabar beramiz." +
        (username ? `\n\n📸 To'lov skrinshotini adminga yuboring: @${esc(username)}` : ""),
    );
  });

  user.callbackQuery(/^watch:(\d+)$/, async (ctx) => {
    const course = db.getCourse(Number(ctx.match[1]));
    if (!course || !db.hasPurchased(ctx.from.id, course.id)) {
      await ctx.answerCallbackQuery({ text: "Bu kurs sizda mavjud emas", show_alert: true });
      return;
    }
    const videos = db.getVideos(course.id);
    if (videos.length === 0) {
      await ctx.answerCallbackQuery({
        text: "Kurs materiallarini admin alohida yuboradi",
        show_alert: true,
      });
      return;
    }
    await ctx.answerCallbackQuery({ text: "Videolar yuborilmoqda..." });
    await deliverCourse(ctx.api, ctx.from.id, course, videos);
  });

  user.on("message", (ctx) =>
    ctx.reply("Quyidagi menyudan kerakli bo'limni tanlang 👇", { reply_markup: mainMenu(isAdmin(ctx)) }),
  );

  return user;
}
