export function loadConfig(env = process.env) {
  const botToken = env.BOT_TOKEN?.trim();
  if (!botToken) throw new Error("BOT_TOKEN .env faylida ko'rsatilmagan");

  const adminIds = (env.ADMIN_IDS ?? "")
    .split(",")
    .map((id) => id.trim())
    .filter(Boolean)
    .map(Number);
  if (adminIds.length === 0 || adminIds.some((id) => !Number.isSafeInteger(id))) {
    throw new Error("ADMIN_IDS .env faylida to'g'ri ko'rsatilmagan (masalan: 123456789,987654321)");
  }

  const channelId = env.CHANNEL_ID?.trim();
  if (!channelId) throw new Error("CHANNEL_ID .env faylida ko'rsatilmagan");

  let channelUrl = env.CHANNEL_URL?.trim();
  if (!channelUrl) {
    if (!channelId.startsWith("@")) {
      throw new Error("Yopiq kanal uchun CHANNEL_URL (taklif havolasi) ko'rsatilishi kerak");
    }
    channelUrl = `https://t.me/${channelId.slice(1)}`;
  }

  return {
    botToken,
    adminIds,
    channelId,
    channelUrl,
    dbPath: env.DB_PATH?.trim() || "./data/bot.db",
  };
}
